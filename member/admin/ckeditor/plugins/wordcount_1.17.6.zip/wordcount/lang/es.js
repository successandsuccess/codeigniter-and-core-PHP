﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'es', {
    WordCount: 'Palabras:',
    CharCount: 'Carácteres:',
    CharCountWithHTML: 'Carácteres (con HTML):',
    Paragraphs: 'Párrafos:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'El contenido no se puede pegar, ya que se encuentra fuera del límite permitido',
    Selected: 'Seleccionado: ',
    title: 'Estadísticas'
});
