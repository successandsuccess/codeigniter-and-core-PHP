﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'en', {
    WordCount: 'Words:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Characters:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Characters (with HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Paragraphs:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Content cannot be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Statistics'
});
