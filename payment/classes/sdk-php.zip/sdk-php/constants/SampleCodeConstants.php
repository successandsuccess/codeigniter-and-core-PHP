<?php
class SampleCodeConstants
{
	//merchant credentials
//	const MERCHANT_LOGIN_ID = "5KP3u95bQpv";
	//const MERCHANT_TRANSACTION_KEY = "346HZ32z3fP4hTG2";
	

	//const MERCHANT_LOGIN_ID = "8s7qEdh4SCdm";
	//const MERCHANT_TRANSACTION_KEY = "7x2Rp5nbP5823V2Y";

	const MERCHANT_LOGIN_ID = "826893tHjSb";
	const MERCHANT_TRANSACTION_KEY = "3j6g3dBG824L8Hcz";


	//api login id - 826893tHjSb
	//transaction key - 3j6g3dBG824L8Hcz
}
?>

