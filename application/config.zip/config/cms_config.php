<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['allow_data_type'] 		= 'xls|xlsx|gif|jpg|jpeg|png|doc|pdf|docx|txt|GIF|JPG|JPEG|PNG|XLS|XLSX|zip|rar|mp4|MP4|mp3|MP3|wav|WAV|pptx|ppt';
$config['adminLink']	 		= 'admin';

/* End of file asset.php */